
# Get Grass 
Get Grass BOT

Register Here : [GetGrass](https://app.getgrass.io/register/?referralCode=NIlT1MR9E2476uA)


## Features

  - Multi Thread
  - Count Proxy Connected
  - Farming x1.25
  - Hemat Bandwith


## Installation

Install with python

1. Download python
2. Install Module (pip install -r requirements.txt)
3. Edit user_id.txt
4. Cara dapat user id : 
   - Login 
   - Inspect > Refresh
   - Cari network retriveUser
   - Buka Preview > Copy user id (diatas user role) CEK SS DIBAWAH
5. Edit proxy di data > proxies.txt 
6. python main.py




![RETRIVE_USER](https://i.ibb.co.com/7Jm9PDK/Cuplikan-layar-2024-07-28-224201.png)
![SSAPP](https://i.ibb.co.com/G5nkXXf/Cuplikan-layar-2024-07-28-224111.png)