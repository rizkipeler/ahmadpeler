
class WebsocketClosedException(Exception):
    pass


class LowProxyScoreException(Exception):
    pass


class ProxyScoreNotFoundException(Exception):
    pass


class ProxyForbiddenException(Exception):
    pass
